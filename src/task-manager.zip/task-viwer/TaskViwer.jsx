import "./TaskViwer.css"
import TaskCard from "../component-task-card/TaskCard"; 

function TaskViwer (props){
    console.log("taskList in TaskViwer", props.taskList);
    return (
    <div className="task-viver-container">
        <div className='task-viver-content'>
          <div className="headings">
            <h3 className="content-heading">Tasks</h3>
            <h4 className="content-subheading">Your tasks in your space.</h4>
          </div>
          <button onClick={props.onCreateClick} className="button-primary"> Create Task</button>
        {props.taskList.map((item, index) => {
          console.log("TaskViwer - Id:", item.Id, "dueDate:", item.dueDate);

          if (item.Id && item.dueDate) {
            return (
              <TaskCard
                key={index}
                Id={item.Id}
                status={item.status}
                content={item.content}
                dueDate={item.dueDate}
              />
            );
          }

          return null;
        })}
        </div>
    </div>
  );

}

export default TaskViwer;
