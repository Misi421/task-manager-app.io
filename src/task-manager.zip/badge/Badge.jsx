import "./Badge.css"

function Badge(props){

    return(
        <div className="task-badge">
            <p>{props.status}</p>
        </div>
    )
}    

export default Badge;